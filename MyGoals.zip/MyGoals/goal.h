#ifndef GOAL_H
#define GOAL_H

#include <QString>

class Goal
{

public:
    Goal(const QString &title,const QString &imgPath,const QString &description,const QString &prog, const QString &subgoals);


    QString getTitle() const;
    void setTitle(const QString &title);
    QString getImgPath() const;
    void setImgPath(const QString &imgPath);
    QString getDescription() const;
    void setDescription(const QString &description);
    QString getProg() const;
    void setProg(const QString &prog);
    QString getSubgoals() const;
    void setSubgoals(const QString &subgoals);

private:
    QString m_title;
    QString m_imgPath;
    QString m_description;
    QString m_prog;
    QString m_subgoals;
};


#endif // GOAL_H
