#include "GoalModel.h"

GoalModel::GoalModel(QObject *parent): QAbstractListModel(parent)
{

}

void GoalModel::addGoal(const Goal &goal)
{
    beginInsertRows(QModelIndex(), rowCount(),rowCount());
    m_goals << goal;
    endInsertRows();

}

void GoalModel::deleteGoal(int row)
{
    beginRemoveRows(QModelIndex(),row,row);
    m_goals.removeAt(row);
    endRemoveRows();
}

void GoalModel::getGoal(int row, QString &mtitle, QString &mimgPath,QString &mdescription,QString &mprog,QString &msubgoals)
{
    mtitle=m_goals[row].getTitle();
    mimgPath=m_goals[row].getImgPath();
    mdescription=m_goals[row].getDescription();
    mprog=m_goals[row].getProg();
    msubgoals=m_goals[row].getSubgoals();
}

void GoalModel::editGoal(int row, QString mytitle, QString myimgPath,QString mydescription,QString myprog,QString msubgoals)
{
    beginRemoveRows(QModelIndex(),row,row);
    m_goals.removeAt(row);
    endRemoveRows();
    Goal goal(mytitle,myimgPath,mydescription,myprog,msubgoals);
    beginInsertRows(QModelIndex(), row, row);
    m_goals.insert(row, goal);
    endInsertRows();
}

int GoalModel::rowCount(const QModelIndex & parent) const {
    Q_UNUSED(parent);
    return m_goals.count();
}


QVariant GoalModel::data(const QModelIndex & index, int role) const {
    if (index.row() < 0 || index.row() >= m_goals.count())
        return QVariant();

    const Goal &goal = m_goals[index.row()];
    if (role == TitleRole)
        return goal.getTitle();
    else if (role == ImgPathRole)
        return goal.getImgPath();
    else if (role == DescriptionRole)
        return goal.getDescription();
    else if (role == ProgRole)
        return goal.getProg();
    else if (role == SubgoalsRole)
        return goal.getSubgoals();
    return QVariant();
}

QHash<int, QByteArray> GoalModel::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[TitleRole] = "title";
    roles[ImgPathRole] = "imgPath";
    roles[DescriptionRole] = "description";
    roles[ProgRole] = "prog";
    roles[SubgoalsRole] = "subgoals";
    return roles;
}
