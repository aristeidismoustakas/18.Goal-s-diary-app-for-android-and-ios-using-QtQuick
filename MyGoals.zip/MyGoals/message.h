#ifndef MESSAGE_H
#define MESSAGE_H

#include <QObject>
#include "Goalmodel.h"
#include "SubGoalmodel.h"

class Message: public QObject
{
    GoalModel *_GoalModel;
    SubGoalModel *_SubGoalModel;

    Q_OBJECT
    Q_PROPERTY(GoalModel* myModel READ myModel WRITE setGoalModel NOTIFY GoalModelChanged)
    Q_PROPERTY(SubGoalModel *mySubGoalModel READ mySubGoalModel WRITE setSubGoalModel NOTIFY SubGoalModelChanged)

public:
    explicit Message(QObject *parent = 0);

    void setGoalModel(GoalModel* m)
    {
        _GoalModel = m;
        emit GoalModelChanged();
    }
    void setSubGoalModel(SubGoalModel* s)
    {
        _SubGoalModel = s;
        emit SubGoalModelChanged();
    }

    GoalModel* myModel()
    {
        return _GoalModel;
    }

    SubGoalModel* mySubGoalModel()
    {
        return _SubGoalModel;
    }

signals:
    void GoalModelChanged();
    void SubGoalModelChanged();
public slots:
    void insertGoal(QString goalTitle,QString,QString,QString);
    void editGoal(int row,QString title,QString image,QString description,QString progress);
    void deleteGoal(int row);

    void insertSubGoal(QString title, QString percentage, bool completed);
    void editSubGoal(int row, QString title, QString percentage, bool completed);
    void deleteSubGoal(int row);

    void goalClicked(int index);

    void clearSubGoalModel();

    QString getSubGoalTitle(int i);
    float getSubGoalPercentage(int i);
    bool getSubGoalCompleted(int i);

    float getSubGoalPercentageTotal();
    float getSubGoalProgress();
};

#endif // MESSAGE_H
