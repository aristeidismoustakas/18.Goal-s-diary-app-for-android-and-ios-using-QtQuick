#ifndef SUBGOAL_H
#define SUBGOAL_H

#include <QString>

class SubGoal
{
public:
    SubGoal(const QString &title,const float &percentage, const bool &completed);

    QString getTitle() const;
    void setTitle(const QString &title);
    float getPercentage() const;
    void setPercentage(const float &percentage);
    bool getCompleted() const;
    void setCompleted(const bool &completed);

private:
    QString m_title;
    float m_percentage;
    bool m_completed;
};

#endif // SUBGOAL_H
