#include "subgoalmodel.h"

SubGoalModel::SubGoalModel(QObject *parent): QAbstractListModel(parent)
{

}

void SubGoalModel::addSubGoal(const SubGoal &subgoal)
{
    beginInsertRows(QModelIndex(), rowCount(),rowCount());
    m_subgoals << subgoal;
    endInsertRows();
}

void SubGoalModel::deleteSubGoal(int row)
{
    beginRemoveRows(QModelIndex(),row,row);
    m_subgoals.removeAt(row);
    endRemoveRows();
}

void SubGoalModel::getSubGoal(int row, QString &title, float &percentage, bool &completed)
{
    title = m_subgoals[row].getTitle();
    percentage = m_subgoals[row].getPercentage();
    completed = m_subgoals[row].getCompleted();
}

void SubGoalModel::editSubGoal(int row, QString title, float percentage, bool completed)
{
    beginRemoveRows(QModelIndex(),row,row);
    m_subgoals.removeAt(row);
    endRemoveRows();
    SubGoal subgoal(title, percentage, completed);
    beginInsertRows(QModelIndex(), row, row);
    m_subgoals.insert(row,subgoal);
    for(int i = 0; i < rowCount(); i++) qDebug("After %s %f %d",m_subgoals[i].getTitle().toStdString().c_str(), m_subgoals[i].getPercentage(), m_subgoals[i].getCompleted());
    endInsertRows();
}

void SubGoalModel::clearModel()
{
    m_subgoals.clear();
}

int SubGoalModel::rowCount(const QModelIndex & parent) const {
    Q_UNUSED(parent);
    return m_subgoals.count();
}


QVariant SubGoalModel::data(const QModelIndex & index, int role) const {
    if (index.row() < 0 || index.row() >= m_subgoals.count())
        return QVariant();

    const SubGoal &subgoal = m_subgoals[index.row()];
    if (role == TitleRole)
        return subgoal.getTitle();
    else if (role == PercentageRole)
        return subgoal.getPercentage();
    else if (role == CompletedRole)
        return subgoal.getCompleted();
    return QVariant();
}


QHash<int, QByteArray> SubGoalModel::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[TitleRole] = "title";
    roles[PercentageRole] = "percentage";
    roles[CompletedRole] = "completed";
    return roles;
}
