#include "subgoal.h"

SubGoal::SubGoal(const QString &title, const float &percentage, const bool &completed)
    : m_title(title), m_percentage(percentage), m_completed(completed)
{

}

QString SubGoal::getTitle() const
{
    return m_title;
}

void SubGoal::setTitle(const QString &title)
{
    if(title != m_title) {
        m_title = title;
    }
}

float SubGoal::getPercentage() const
{
    return m_percentage;
}

void SubGoal::setPercentage(const float &percentage)
{
    if(percentage != m_percentage) {
        m_percentage = percentage;
    }
}

bool SubGoal::getCompleted() const
{
    return m_completed;
}

void SubGoal::setCompleted(const bool &completed)
{
    if(completed != m_completed) {
        m_completed = completed;
    }
}
