#include "Goal.h"

Goal::Goal(const QString &title,const QString &imgPath,const QString &description,const QString &prog,const QString &subgoals)
    : m_title(title),m_imgPath(imgPath),m_description(description),m_prog(prog),m_subgoals(subgoals)
{
}


QString Goal::getTitle() const
{
    return m_title;
}

void Goal::setTitle(const QString &title)
{
    if (title != m_title) {
        m_title = title;
    }
}

QString Goal::getImgPath() const
{
    return m_imgPath;
}

void Goal::setImgPath(const QString &imgPath)
{
    if (imgPath != m_imgPath) {
        m_imgPath = imgPath;
    }
}

QString Goal::getDescription() const
{
    return m_description;
}

void Goal::setDescription(const QString &description)
{
    if (description != m_description) {
        m_description = description;
    }
}

QString Goal::getProg() const
{
    return m_prog;
}

void Goal::setProg(const QString &prog)
{
    if (prog != m_prog) {
        m_prog = prog;
    }
}

QString Goal::getSubgoals() const
{
    return m_subgoals;
}

void Goal::setSubgoals(const QString &subgoals)
{
    if(subgoals != m_subgoals) {
        m_subgoals = subgoals;
    }
}

