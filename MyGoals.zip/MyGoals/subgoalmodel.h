#ifndef SUBGOALMODEL_H
#define SUBGOALMODEL_H

#include <QAbstractListModel>
#include "subgoal.h"

class SubGoalModel : public QAbstractListModel
{
    Q_OBJECT

public:

    enum SubGoalRoles {
        TitleRole = Qt::UserRole + 1,
        PercentageRole, CompletedRole
    };

    SubGoalModel(QObject *parent = 0);

    void addSubGoal(const SubGoal &subgoal);
    void getSubGoal(int row, QString &title, float &percentage, bool &completed);
    void editSubGoal(int row, QString title, float percentage, bool completed);
    void clearModel();
    int rowCount(const QModelIndex &parent = QModelIndex()) const;

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;

    void deleteSubGoal(int row);

protected:
    QHash<int, QByteArray> roleNames() const;
private:
    QList<SubGoal> m_subgoals;
};

#endif // SUBGOALMODEL_H
