#ifndef GOALMODEL_H
#define GOALMODEL_H

#include <QObject>
#include <QAbstractListModel>
#include "Goal.h"


class GoalModel : public QAbstractListModel
{
    Q_OBJECT
    public:
        enum GoalRoles {
            TitleRole = Qt::UserRole + 1,
            ImgPathRole,DescriptionRole,ProgRole,SubgoalsRole
        };

        GoalModel(QObject *parent = 0);

        void addGoal(const Goal &goal);
        void getGoal(int row, QString &title, QString &imgPath,QString &description,QString &prog, QString &subgoals);
        void editGoal(int row, QString mytitle, QString myimgPath,QString mydescription,QString myprog, QString mysubgoals);
        int rowCount(const QModelIndex & parent = QModelIndex()) const;

        QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;

        void deleteGoal(int row);
    protected:
        QHash<int, QByteArray> roleNames() const;
    private:
        QList<Goal> m_goals;
};

#endif // GOALMODEL_H
