#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QStringList>
#include <qqmlcontext.h>
#include "goal.h"
#include "goalmodel.h"
#include "message.h"
int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    Message *msg = new Message();

    engine.rootContext()->setContextProperty("message",msg);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}
