#include "Message.h"

#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QTextStream>

Message::Message(QObject *parent) : QObject(parent)
{
    _GoalModel = new GoalModel();
    _SubGoalModel = new SubGoalModel();

    QString s ="data.txt";

    qDebug(s.toLatin1());
    QFile qf(s);
    qf.open(QIODevice::ReadOnly | QIODevice::Text);

    QTextStream in(&qf);
    while (!in.atEnd())
    {
        QString ctitle = in.readLine();
        QString cimgPath = in.readLine();
        QString cdescription = in.readLine();
        QString cprog = in.readLine();
        QString csubgoals = in.readLine();
        _GoalModel->addGoal(Goal(ctitle,cimgPath,cdescription,cprog,csubgoals));
    }
    qf.close();

}
void Message::insertGoal(QString goalTitle,QString imagePath,QString description,QString prog)
{
    qDebug(prog.toUtf8().constData());
    if(goalTitle.trimmed().isEmpty()) return;

    QString s ="data.txt";
    if(!QDir("goalsImages").exists())
    {
        QDir().mkdir("goalsImages");
    }
    QFile qf(s);
    QTextStream out(&qf);
    QString type;

    if(imagePath.endsWith(".png")){
        type=".png";
    }else
    {
        type=".jpg";
    }
    QDir dir(QDir::currentPath());
    dir.cdUp();
    QString link=QDir::currentPath();
    link.append("/goalsImages/");
    link.append(goalTitle).append(type);
    QString finalImagePath = imagePath.right(imagePath.length()-8);
    //qDebug(link.toUtf8().constData());
    QFile::copy(finalImagePath, link);
    QString aa="file:///";
    aa.append(link);

    QString subgoals = "";
    QString title;
    float percentage;
    bool completed;

    for(int i = 0; i < _SubGoalModel->rowCount(); i++) {
        _SubGoalModel->getSubGoal(i, title, percentage, completed);
        qDebug("%s %f %d", title.toStdString().c_str(), percentage, completed);
        int temp=0;
        if(completed) temp=1;
        subgoals.append(title+"_"+QString(std::to_string(percentage).c_str())+"_"+QString(std::to_string(temp).c_str())+";");
    }

    qDebug("Subgoals: %s",subgoals.toStdString().c_str());

    _GoalModel->addGoal(Goal(goalTitle,aa,description,prog,subgoals));
    qf.open(QIODevice::Append | QIODevice::Text);

    out<<goalTitle<<endl;
    out<<aa<<endl;
    out<<description<<endl;
    out<<prog<<endl;
    out<<subgoals<<endl;
    qf.close();


}

void Message::deleteGoal(int row)
{
    //Remove image from goal
    QString titlegoal,path,desc,prog,subgoals;
    _GoalModel->getGoal(row,titlegoal,path,desc,prog,subgoals);
    QString finalImagePath = path.right(path.length()-8);
    QFile image(finalImagePath);
    image.remove();

    _GoalModel->deleteGoal(row);

    QString s ="data.txt";
    QFile qf(s);
    QTextStream out(&qf);

    qf.open(QIODevice::WriteOnly | QIODevice::Text);

    for (int i=0;i<_GoalModel->rowCount();i++)
    {
        QString titlegoal,path,desc,prog,subgoals;
        _GoalModel->getGoal(i,titlegoal,path,desc,prog,subgoals);
        out<<titlegoal<<endl;
        out<<path<<endl;
        out<<desc<<endl;
        out<<prog<<endl;
        out<<subgoals<<endl;
    }
    qf.close();
}

void Message::editGoal(int row,QString title,QString image,QString description,QString progress)
{

    QString subgoals = "";
    QString subGoalTitle;
    float percentage;
    bool completed;

    for(int i = 0; i < _SubGoalModel->rowCount(); i++) {
        _SubGoalModel->getSubGoal(i, subGoalTitle, percentage, completed);
        qDebug("%s %f %d", subGoalTitle.toStdString().c_str(), percentage, completed);
        int temp=0;
        if(completed) temp=1;
        subgoals.append(subGoalTitle+"_"+QString(std::to_string(percentage).c_str())+"_"+QString(std::to_string(temp).c_str())+";");
    }

    _GoalModel->editGoal(row,title,image,description,progress,subgoals);

    QString s ="data.txt";
    QFile qf(s);
    QTextStream out(&qf);

    qf.open(QIODevice::WriteOnly | QIODevice::Text);


    for (int i=0;i<_GoalModel->rowCount();i++)
    {
        QString titlegoal,path,desc,prog,subgoals;
        _GoalModel->getGoal(i,titlegoal,path,desc,prog,subgoals);
        out<<titlegoal<<endl;
        out<<path<<endl;
        out<<desc<<endl;
        out<<prog<<endl;
        out<<subgoals<<endl;
    }
    qf.close();
}

void Message::insertSubGoal(QString title, QString percentage, bool completed)
{
    _SubGoalModel->addSubGoal(SubGoal(title, std::stof(percentage.toStdString().c_str()), completed));
}

void Message::editSubGoal(int row, QString title, QString percentage, bool completed)
{
    _SubGoalModel->editSubGoal(row, title, std::stof(percentage.toStdString().c_str()), completed);
}

void Message::deleteSubGoal(int row)
{
    if(row >= 0) _SubGoalModel->deleteSubGoal(row);
}

/*
 * Called when a goal is clicked in the main form.
 * Populates the subgoal model with that goal's subgoals.
 */
void Message::goalClicked(int index)
{
    _SubGoalModel->clearModel();
    QString a,b,c,d,e;
    _GoalModel->getGoal(index,a,b,c,d,e);
    QStringList subgoals = e.split(";",QString::KeepEmptyParts);

    for(int i = 0; i < subgoals.size(); i++) {
        QStringList fields = QString(subgoals.at(i)).split("_", QString::KeepEmptyParts);
        if(fields.size() >= 3) //Auta einai kalo na min ginonte
        {
        bool completed = false;
        if(std::stoi(QString(fields.at(2)).toStdString().c_str()) == 1) completed = true;
        _SubGoalModel->addSubGoal(SubGoal(QString(fields.at(0))
                                          ,std::stof(QString(fields.at(1)).toStdString().c_str())
                                          ,completed));
        }
    }
}

void Message::clearSubGoalModel()
{
    _SubGoalModel->clearModel();
}

QString Message::getSubGoalTitle(int i)
{
    QString title;
    float percentage;
    bool completed;
    _SubGoalModel->getSubGoal(i,title,percentage,completed);
    return title;
}

float Message::getSubGoalPercentage(int i)
{
    QString title;
    float percentage;
    bool completed;
    _SubGoalModel->getSubGoal(i,title,percentage,completed);
    return percentage;
}

bool Message::getSubGoalCompleted(int i)
{
    QString title;
    float percentage;
    bool completed;
    _SubGoalModel->getSubGoal(i,title,percentage,completed);
    return completed;
}

float Message::getSubGoalPercentageTotal()
{
    QString title;
    float percentage;
    bool completed;
    float total = 0;

    if(_SubGoalModel->rowCount() >= 0)
        for(int i = 0; i < _SubGoalModel->rowCount(); i++) {
            _SubGoalModel->getSubGoal(i,title,percentage,completed);
            total+=percentage;
        }

    return total;
}

float Message::getSubGoalProgress()
{
    QString title;
    float percentage;
    bool completed;
    float progress = 0;

    if(_SubGoalModel->rowCount() >= 0)
        for(int i = 0; i < _SubGoalModel->rowCount(); i++) {
            _SubGoalModel->getSubGoal(i,title,percentage,completed);
            if(completed) {
                progress+=percentage;
            }
        }

    return progress;
}
